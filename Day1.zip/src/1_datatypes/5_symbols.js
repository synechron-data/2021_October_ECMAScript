// var result = 10 * 'abc';
// console.log(result);

// T && T = T
// T && F = F

// console.log(true && "abc");
// console.log(false && "abc");

// console.log(true && "abc" || "xyz");
// console.log(false && "abc" || "xyz");

// console.log(true ? "abc" : "xyz");
// console.log(false ? "abc" : "xyz");

// <h1 className={isSelect && "text-danger" || "text-success"}>

// </h1>

// <h1 class={{isSelect && "text-danger" || "text-success"}}>

// </h1>

// console.log(Boolean(0));
// console.log(Boolean(1));
// console.log(Boolean(-1));
// console.log(Boolean(""));
// console.log(Boolean("abc"));
// console.log(Boolean(undefined));
// console.log(Boolean(null));

// var obj = null;
// // var obj = undefined;
// // var obj = { id: 1 };

// // if ((obj === null) || (obj === undefined)) {
// //     console.log("object is null or undefined");
// // } else {
// //     console.log("object is: ", obj);
// // }

// if (!obj) {
//     console.log("object is null or undefined");
// } else {
//     console.log("object is: ", obj);
// }

// --------------------------------------------

// var a = 10;
// var b = "10";

// console.log(a == b);        // Abstract Equality
// console.log(a === b);        // Strict Equality

// var a = { id: 10 };
// var b = { id: 10 };
// var c = b;

// console.log(a == b);        // Abstract Equality
// console.log(a === b);        // Strict Equality

// console.log(b == c);       // Abstract Equality
// console.log(b === c);      // Strict Equality

// --------------------------------------------------------------

// const color = "red";

// function isRedColor(str) {
//     // This funtion should return true only if color constant is passed as an argument
//     return (str === color);
// }

// console.log(isRedColor(color));
// console.log(isRedColor("red"));

// var c = "red";
// console.log(isRedColor(c));

// -----------------------------------
// const color = { clur: "red" };

// function isRedColor(str) {
//     // This funtion should return true only if color constant is passed as an argument
//     return (str === color);
// }

// console.log(isRedColor(color));
// console.log(isRedColor({ clur: "red" }));

// var c = { clur: "red" };
// console.log(isRedColor(c));

// ------------------------------------------------- ECMASCRIPT 2015 - Symbol (Unique Immutables)
const color = Symbol("red");

function isRedColor(str) {
    // This funtion should return true only if color constant is passed as an argument
    return (str === color);
}

console.log(isRedColor(color));
console.log(isRedColor(Symbol("red")));

var c = Symbol("red");
console.log(isRedColor(c));