// Case 1 - Default Export
// export default function square(x) {
//     return x * x;
// }

// Case 2 - Named Exports - Multiple Exports
// export function square(x) {
//     return x * x;
// }

// export function check(x) {
//     return `Checked: ${x}`;
// }

// function test(x) {
//     return `Test: ${x}`;
// }

// Only one default export allowed per module.
// Case 3 - Default and Named Exports
// export default function square(x) {
//     return x * x;
// }

// export function check(x) {
//     return `Checked: ${x}`;
// }

export default {
    id: 1,
    name: "Manish",
    display: function () {
        console.log(this);
    }
};