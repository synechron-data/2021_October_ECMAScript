module.exports = function (env) {
    // console.log("webpack.config.js is loaded - ", env);
    var env_file = env.WEBPACK_SERVE ? 'dev' : 'prod';
    return require(`./config/webpack.${env_file}.js`)(env);
}