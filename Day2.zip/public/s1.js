// function hello() {
//     console.log("Hello from S1");
// }

var s1;

(function (ns) {
    function hello() {
        console.log("Hello from S1");
    }

    ns.hello = hello;
})(s1 = s1 || {});

// Module Pattern