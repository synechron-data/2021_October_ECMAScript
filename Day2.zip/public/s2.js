// function hello() {
//     console.log("Hello from S2");
// }

var s2;

(function (ns) {
    function hello() {
        console.log("Hello from S2");
    }

    ns.hello = hello;
})(s2 = s2 || {});