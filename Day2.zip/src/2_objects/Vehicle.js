export default class Vehicle {
    constructor(m) {
        this._make = m;
    }

    start() {
        return `${this._make}, engine started`;
    }
}