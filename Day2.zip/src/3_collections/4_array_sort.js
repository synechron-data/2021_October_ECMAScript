var employees = ["Chethan", "Akshay", "Bhavya", "Bibhu", "Chhavi", "Basavaraj"];

console.log(employees);

// sort() overwrites the original array.
console.log(employees.sort());
console.log(employees);
